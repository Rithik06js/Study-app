/*
  # Add user tracking table

  1. New Tables
    - `user_visits`
      - `id` (uuid, primary key)
      - `name` (text, not null)
      - `visited_at` (timestamp with time zone)
      - `last_active` (timestamp with time zone)

  2. Security
    - Enable RLS on `user_visits` table
    - Add policy for admins to read all visits
*/

CREATE TABLE IF NOT EXISTS user_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  visited_at timestamptz DEFAULT now(),
  last_active timestamptz DEFAULT now()
);

ALTER TABLE user_visits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can read all user visits"
  ON user_visits
  FOR SELECT
  TO authenticated
  USING ((auth.jwt() ->> 'role'::text) = 'admin'::text);

CREATE POLICY "Anyone can insert user visits"
  ON user_visits
  FOR INSERT
  TO public
  WITH CHECK (true);