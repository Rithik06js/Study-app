/*
  # Fix chapter permissions and policies

  1. Changes
    - Update RLS policies for chapters table
    - Add policies for authenticated users to manage chapters
    - Add policies for chapter_contents table

  2. Security
    - Enable RLS on chapters table
    - Add policies for CRUD operations
    - Ensure proper cascade delete behavior
*/

-- Enable RLS for chapters table
ALTER TABLE chapters ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Admins can delete chapters" ON chapters;
DROP POLICY IF EXISTS "Admins can insert chapters" ON chapters;
DROP POLICY IF EXISTS "Admins can update chapters" ON chapters;
DROP POLICY IF EXISTS "Anyone can read chapters" ON chapters;

-- Create new policies for chapters
CREATE POLICY "Enable read access for all users" ON chapters
  FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users" ON chapters
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users" ON chapters
  FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users" ON chapters
  FOR DELETE TO authenticated
  USING (true);

-- Enable RLS for chapter_contents table
ALTER TABLE chapter_contents ENABLE ROW LEVEL SECURITY;

-- Create policies for chapter_contents
CREATE POLICY "Enable read access for all users" ON chapter_contents
  FOR SELECT USING (true);

CREATE POLICY "Enable insert for authenticated users" ON chapter_contents
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users" ON chapter_contents
  FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users" ON chapter_contents
  FOR DELETE TO authenticated
  USING (true);