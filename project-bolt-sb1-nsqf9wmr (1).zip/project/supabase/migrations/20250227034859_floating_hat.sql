/*
  # Initial Schema Setup for E-Learning Platform

  1. New Tables
    - `subjects` - Stores subject information
      - `id` (uuid, primary key)
      - `name` (text, subject name)
      - `icon` (text, icon identifier)
      - `created_at` (timestamp)
    
    - `chapters` - Stores chapter information
      - `id` (uuid, primary key)
      - `subject_id` (uuid, foreign key to subjects)
      - `name` (text, chapter name)
      - `order` (integer, for sorting chapters)
      - `created_at` (timestamp)
    
    - `chapter_contents` - Stores content for each chapter
      - `id` (uuid, primary key)
      - `chapter_id` (uuid, foreign key to chapters)
      - `read_content` (text, PDF URL or content)
      - `video_url` (text, YouTube or video URL)
      - `extra_info` (text, additional information)
      - `quick_revision` (text, revision notes)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read all data
    - Add policies for admin users to manage all data
*/

-- Create subjects table
CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  icon text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create chapters table
CREATE TABLE IF NOT EXISTS chapters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  name text NOT NULL,
  "order" integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create chapter_contents table
CREATE TABLE IF NOT EXISTS chapter_contents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
  read_content text,
  video_url text,
  extra_info text,
  quick_revision text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE chapter_contents ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access to subjects
CREATE POLICY "Anyone can read subjects"
  ON subjects
  FOR SELECT
  TO public
  USING (true);

-- Create policy for public read access to chapters
CREATE POLICY "Anyone can read chapters"
  ON chapters
  FOR SELECT
  TO public
  USING (true);

-- Create policy for public read access to chapter_contents
CREATE POLICY "Anyone can read chapter_contents"
  ON chapter_contents
  FOR SELECT
  TO public
  USING (true);

-- Create policies for admin to manage subjects
CREATE POLICY "Admins can insert subjects"
  ON subjects
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can update subjects"
  ON subjects
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can delete subjects"
  ON subjects
  FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');

-- Create policies for admin to manage chapters
CREATE POLICY "Admins can insert chapters"
  ON chapters
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can update chapters"
  ON chapters
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can delete chapters"
  ON chapters
  FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');

-- Create policies for admin to manage chapter_contents
CREATE POLICY "Admins can insert chapter_contents"
  ON chapter_contents
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can update chapter_contents"
  ON chapter_contents
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Admins can delete chapter_contents"
  ON chapter_contents
  FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');