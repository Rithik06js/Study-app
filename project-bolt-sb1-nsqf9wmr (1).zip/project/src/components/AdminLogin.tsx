import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, User, Mail, Key, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

export function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  // Keyboard shortcut for admin access
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + O shortcut for quick admin access
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        navigate('/admin', { state: { fromShortcut: true } });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // For demo purposes, allow a default admin login
      // In production, you would remove this and use only real authentication
      if (email === 'admin@example.com' && password === 'admin123') {
        // Simulate successful login
        navigate('/admin', { state: { fromLogin: true } });
        return;
      }
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      
      // After successful login, navigate to admin dashboard
      navigate('/admin');
    } catch (error) {
      console.error('Error logging in:', error);
      setError('Invalid email or password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
        backgroundPosition: 'center',
      }}
    >
      <div className="w-full max-w-md p-8 backdrop-blur-md bg-white/20 rounded-xl shadow-2xl border border-white/30">
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center mb-4">
            <Lock size={36} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white drop-shadow-lg">Admin Portal</h1>
          <p className="text-white/80 mt-2">Enter your credentials to access the dashboard</p>
          <div className="mt-2 text-white/60 text-xs">
            <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">Ctrl</kbd>
            <span className="mx-1">+</span>
            <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">O</kbd>
            <span className="ml-1">Quick Access</span>
          </div>
        </div>
        
        {error && (
          <div className="mb-6 p-4 bg-red-500/30 backdrop-blur-sm border border-red-500/50 rounded-lg flex items-center">
            <AlertCircle size={20} className="text-white mr-2" />
            <p className="text-white text-sm">{error}</p>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="email" className="block text-sm font-medium text-white">
              Email
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail size={18} className="text-white/60" />
              </div>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 block w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/50"
                placeholder="admin@example.com"
                required
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm font-medium text-white">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Key size={18} className="text-white/60" />
              </div>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 block w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/50"
                placeholder="••••••••"
                required
              />
            </div>
          </div>
          
          <button
            type="submit"
            disabled={loading}
            className={`w-full px-4 py-3 ${
              loading 
                ? 'bg-blue-500/70' 
                : 'bg-blue-600 hover:bg-blue-700'
            } text-white rounded-lg transition-all duration-200 ease-in-out transform hover:scale-105 flex items-center justify-center`}
          >
            {loading ? (
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <>
                <User size={20} className="mr-2" />
                <span>Sign In</span>
              </>
            )}
          </button>
        </form>
        
        <div className="mt-6 text-center">
          <p className="text-white/70 text-sm">
            Demo credentials: admin@example.com / admin123
          </p>
        </div>
      </div>
    </div>
  );
}