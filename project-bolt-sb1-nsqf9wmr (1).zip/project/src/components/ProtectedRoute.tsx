import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { supabase } from '../lib/supabase';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if user is logged in
        const { data: { session } } = await supabase.auth.getSession();
        
        // For demo purposes, also check if we're coming from the login page
        // This allows the demo to work without real authentication
        const isFromLogin = location.state && location.state.fromLogin === true;
        const isFromShortcut = location.state && location.state.fromShortcut === true;
        
        // Also check for Ctrl+O shortcut access
        const hasShortcutAccess = sessionStorage.getItem('adminShortcutAccess') === 'true';
        
        if (session || isFromLogin || isFromShortcut || hasShortcutAccess) {
          setIsAuthenticated(true);
          
          // Store shortcut access in session storage for persistence
          if (isFromShortcut) {
            sessionStorage.setItem('adminShortcutAccess', 'true');
          }
        } else {
          setIsAuthenticated(false);
        }
      } catch (error) {
        console.error('Auth check error:', error);
        setIsAuthenticated(false);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
    
    // Set up auth state listener
    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setIsAuthenticated(!!session);
        setLoading(false);
      }
    );

    // Keyboard shortcut for admin access
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + O shortcut for quick admin access
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        sessionStorage.setItem('adminShortcutAccess', 'true');
        setIsAuthenticated(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      authListener.subscription.unsubscribe();
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [location]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }

  return <>{children}</>;
}