import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Monitor, 
  Globe2, 
  BookOpen, 
  Book, 
  FlaskRound as Flask, 
  Atom, 
  Calculator, 
  Languages, 
  BookMarked, 
  BookText,
  LogOut
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Subject } from '../lib/supabase';

interface SubjectsGridProps {
  userName: string;
}

// Icon mapping
const iconMap: Record<string, React.ElementType> = {
  'Monitor': Monitor,
  'Globe2': Globe2,
  'BookOpen': BookOpen,
  'Book': Book,
  'BookText': BookText,
  'Flask': Flask,
  'Atom': Atom,
  'Calculator': Calculator,
  'Languages': Languages,
  'BookMarked': BookMarked
};

export function SubjectsGrid({ userName }: SubjectsGridProps) {
  const navigate = useNavigate();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchSubjects();
  }, []);

  // Keyboard shortcut for admin access
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + O shortcut for quick admin access
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        navigate('/admin');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name');
      
      if (error) throw error;
      
      setSubjects(data || []);
    } catch (err) {
      console.error('Error fetching subjects:', err);
      setError('Failed to load subjects. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 p-8 flex flex-col items-center justify-center">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Error</h2>
          <p className="text-gray-700 mb-6">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat bg-fixed"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
        backgroundColor: 'rgba(0,0,0,0.7)',
        backgroundBlendMode: 'overlay',
      }}
    >
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-white">
            Welcome back, Mr. {userName}
          </h1>
          <div className="flex items-center space-x-4">
            <div className="text-white/60 text-sm hidden md:block">
              <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">Ctrl</kbd>
              <span className="mx-1">+</span>
              <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">O</kbd>
              <span className="ml-1">for Admin Access</span>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white rounded-lg transition-colors flex items-center space-x-2 border border-white/20"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {subjects.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <BookOpen size={64} className="mx-auto text-white/50 mb-4" />
              <p className="text-white text-xl">No subjects available yet.</p>
            </div>
          ) : (
            subjects.map((subject) => {
              // Get the icon component or default to BookOpen
              const IconComponent = iconMap[subject.icon] || BookOpen;
              
              return (
                <button
                  key={subject.id}
                  onClick={() => navigate(`/subject/${subject.id}`)}
                  className="p-8 bg-white/10 backdrop-blur-md rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col items-center space-y-4 border border-white/20 hover:bg-white/20 hover:scale-105 transform"
                >
                  <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center">
                    <IconComponent size={32} className="text-white" />
                  </div>
                  <h2 className="text-xl font-semibold text-white text-center">
                    {subject.name}
                  </h2>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}