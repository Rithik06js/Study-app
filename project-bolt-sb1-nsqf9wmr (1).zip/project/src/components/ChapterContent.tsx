import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { BookOpen, Video, Info, Brain, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Chapter, ChapterContent as ChapterContentType } from '../lib/supabase';

export function ChapterContent() {
  const { chapterId } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'read' | 'video' | 'extra' | 'revision'>('read');
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [content, setContent] = useState<ChapterContentType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const tabs = [
    { id: 'read', name: 'Read Chapter', icon: BookOpen },
    { id: 'video', name: 'Watch Video', icon: Video },
    { id: 'extra', name: 'Extra Information', icon: Info },
    { id: 'revision', name: 'Quick Revision', icon: Brain },
  ] as const;

  useEffect(() => {
    if (chapterId) {
      fetchChapterData();
    }
  }, [chapterId]);

  // Keyboard shortcut for admin access
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + O shortcut for quick admin access
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        navigate('/admin');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);

  const fetchChapterData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch chapter details
      const { data: chapterData, error: chapterError } = await supabase
        .from('chapters')
        .select('*, subjects(name)')
        .eq('id', chapterId)
        .single();
      
      if (chapterError) throw chapterError;
      setChapter(chapterData);
      
      // Fetch chapter content
      const { data: contentData, error: contentError } = await supabase
        .from('chapter_contents')
        .select('*')
        .eq('chapter_id', chapterId);
      
      if (contentError) throw contentError;
      
      // Set content to the first item if it exists, otherwise null
      setContent(contentData && contentData.length > 0 ? contentData[0] : null);
    } catch (err) {
      console.error('Error fetching chapter data:', err);
      setError('Failed to load chapter content. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleBackClick = () => {
    navigate(`/subject/${chapter?.subject_id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 p-8 flex flex-col items-center justify-center">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Error</h2>
          <p className="text-gray-700 mb-6">{error}</p>
          <button
            onClick={handleBackClick}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="min-h-screen bg-gray-100 p-8 flex flex-col items-center justify-center">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Chapter Not Found</h2>
          <p className="text-gray-700 mb-6">The requested chapter could not be found.</p>
          <button
            onClick={() => navigate('/subjects')}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Return to Subjects
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat bg-fixed"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
        backgroundColor: 'rgba(0,0,0,0.7)',
        backgroundBlendMode: 'overlay',
      }}
    >
      <div className="container mx-auto px-4 py-8">
        <button
          onClick={handleBackClick}
          className="mb-6 flex items-center text-white hover:text-blue-300 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Chapters</span>
        </button>

        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">{chapter.name}</h1>
            <p className="text-blue-300">{(chapter as any).subjects?.name}</p>
          </div>

          {!content ? (
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 text-center border border-white/20">
              <BookOpen size={48} className="mx-auto text-white/50 mb-4" />
              <p className="text-white text-lg">No content available for this chapter yet.</p>
              <p className="text-white/70 mt-2">Please check back later or contact an administrator.</p>
            </div>
          ) : (
            <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 overflow-hidden">
              <div className="flex flex-wrap border-b border-white/20">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  const hasContent = content[
                    tab.id === 'read' ? 'read_content' :
                    tab.id === 'video' ? 'video_url' :
                    tab.id === 'extra' ? 'extra_info' :
                    'quick_revision'
                  ];

                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      disabled={!hasContent}
                      className={`
                        flex items-center px-6 py-4 focus:outline-none transition-colors
                        ${isActive 
                          ? 'bg-white/20 text-white' 
                          : 'text-white/70 hover:text-white hover:bg-white/10'}
                        ${!hasContent && 'opacity-50 cursor-not-allowed'}
                      `}
                    >
                      <Icon size={20} className="mr-2" />
                      <span>{tab.name}</span>
                    </button>
                  );
                })}
              </div>

              <div className="p-6">
                {activeTab === 'read' && content.read_content && (
                  <div className="aspect-video">
                    <iframe
                      src={content.read_content}
                      className="w-full h-full rounded-lg"
                      allow="autoplay"
                    />
                  </div>
                )}

                {activeTab === 'video' && content.video_url && (
                  <div className="aspect-video">
                    <iframe
                      src={content.video_url.replace('watch?v=', 'embed/')}
                      className="w-full h-full rounded-lg"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                )}

                {activeTab === 'extra' && content.extra_info && (
                  <div className="prose prose-invert max-w-none">
                    <div className="text-white whitespace-pre-wrap">{content.extra_info}</div>
                  </div>
                )}

                {activeTab === 'revision' && content.quick_revision && (
                  <div className="prose prose-invert max-w-none">
                    <div className="text-white whitespace-pre-wrap">{content.quick_revision}</div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}