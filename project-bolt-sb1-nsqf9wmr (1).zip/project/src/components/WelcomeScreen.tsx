import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, BookOpen, Sparkles, Lock } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface WelcomeScreenProps {
  userName: string;
  setUserName: (name: string) => void;
}

export function WelcomeScreen({ userName, setUserName }: WelcomeScreenProps) {
  const [isEntered, setIsEntered] = useState(false);
  const [showAdminAccess, setShowAdminAccess] = useState(false);
  const [adminKey, setAdminKey] = useState('');
  const [adminKeyError, setAdminKeyError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        navigate('/admin');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userName.trim()) {
      try {
        // Save user visit to Supabase
        await supabase.from('user_visits').insert([{ name: userName.trim() }]);
        setIsEntered(true);
      } catch (error) {
        console.error('Error saving user visit:', error);
        // Continue even if saving fails
        setIsEntered(true);
      }
    }
  };

  const handleEnterClick = () => {
    navigate('/subjects');
  };

  const handleAdminKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminKey === 'admin123') {
      navigate('/admin/login');
    } else {
      setAdminKeyError('Invalid admin key. Please try again.');
    }
  };

  const toggleAdminAccess = () => {
    setShowAdminAccess(!showAdminAccess);
    setAdminKeyError('');
  };

  if (!isEntered) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat bg-fixed"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80")',
          backgroundColor: 'rgba(0,0,0,0.6)',
          backgroundBlendMode: 'overlay',
        }}
      >
        <div className="w-full max-w-md p-8 backdrop-blur-md bg-white/20 rounded-2xl shadow-2xl border border-white/30">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
              <BookOpen size={36} className="text-white" />
            </div>
          </div>
          
          {!showAdminAccess ? (
            <>
              <form onSubmit={handleSubmit} className="space-y-6">
                <h1 className="text-4xl font-bold text-white text-center mb-8 drop-shadow-lg">
                  Welcome Student
                </h1>
                <div className="relative">
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full px-4 py-3 rounded-lg bg-white/30 backdrop-blur-sm border border-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/70"
                    required
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <Sparkles size={20} className="text-white/70" />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-lg transition duration-200 ease-in-out transform hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <span>Continue</span>
                  <ArrowRight size={20} />
                </button>
              </form>
              
              <div className="mt-8 pt-6 border-t border-white/20 text-center">
                <div className="flex flex-col items-center space-y-2">
                  <button 
                    onClick={toggleAdminAccess}
                    className="text-white/70 hover:text-white text-sm flex items-center justify-center mx-auto transition-colors"
                  >
                    <Lock size={14} className="mr-1" />
                    <span>Admin Access</span>
                  </button>
                  <div className="text-white/60 text-xs">
                    <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">Ctrl</kbd>
                    <span className="mx-1">+</span>
                    <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">O</kbd>
                    <span className="ml-1">Quick Admin Access</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <>
              <form onSubmit={handleAdminKeySubmit} className="space-y-6">
                <h1 className="text-3xl font-bold text-white text-center mb-6 drop-shadow-lg">
                  Admin Access
                </h1>
                <div className="relative">
                  <input
                    type="password"
                    value={adminKey}
                    onChange={(e) => {
                      setAdminKey(e.target.value);
                      setAdminKeyError('');
                    }}
                    placeholder="Enter admin key"
                    className="w-full px-4 py-3 rounded-lg bg-white/30 backdrop-blur-sm border border-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-white/70"
                    required
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <Lock size={20} className="text-white/70" />
                  </div>
                </div>
                
                {adminKeyError && (
                  <div className="bg-red-500/30 backdrop-blur-sm border border-red-500/50 rounded-lg p-2 text-white text-sm">
                    {adminKeyError}
                  </div>
                )}
                
                <button
                  type="submit"
                  className="w-full px-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg transition duration-200 ease-in-out transform hover:scale-105 flex items-center justify-center space-x-2"
                >
                  <span>Access Admin</span>
                  <ArrowRight size={20} />
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <button 
                  onClick={toggleAdminAccess}
                  className="text-white/70 hover:text-white text-sm transition-colors"
                >
                  Back to student login
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center bg-cover bg-center bg-no-repeat bg-fixed"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&q=80")',
        backgroundColor: 'rgba(0,0,0,0.6)',
        backgroundBlendMode: 'overlay',
      }}
    >
      <div className="text-center p-8 backdrop-blur-md bg-white/20 rounded-2xl shadow-2xl border border-white/30 max-w-lg">
        <div className="flex justify-center mb-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 flex items-center justify-center">
            <BookOpen size={48} className="text-white" />
          </div>
        </div>
        
        <h1 className="text-5xl font-bold text-white mb-4 drop-shadow-lg">
          Welcome, Mr. {userName}
        </h1>
        <p className="text-2xl text-white/80 mb-8">
          Ready to study?
        </p>
        <button
          onClick={handleEnterClick}
          className="px-8 py-4 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white rounded-lg transition duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center space-x-2 mx-auto shadow-lg"
        >
          <span className="text-xl font-semibold">Enter</span>
          <ArrowRight size={24} />
        </button>
        
        <div className="mt-8 pt-4 border-t border-white/20">
          <div className="flex flex-col items-center space-y-2">
            <button 
              onClick={() => navigate('/admin/login')}
              className="text-white/60 hover:text-white text-sm flex items-center justify-center mx-auto transition-colors"
            >
              <Lock size={14} className="mr-1" />
              <span>Admin Login</span>
            </button>
            <div className="text-white/60 text-xs">
              <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">Ctrl</kbd>
              <span className="mx-1">+</span>
              <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">O</kbd>
              <span className="ml-1">Quick Admin Access</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}