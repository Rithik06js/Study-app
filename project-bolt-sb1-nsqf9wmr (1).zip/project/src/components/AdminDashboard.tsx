import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Plus, 
  Trash2, 
  Edit, 
  Book, 
  LogOut, 
  AlertCircle,
  Users,
  Layout,
  BookOpen,
  Monitor,
  Globe2,
  BookText,
  FlaskRound as Flask,
  Atom,
  Calculator,
  Languages,
  BookMarked,
  FileText,
  Video,
  Info,
  Brain
} from 'lucide-react';
import { UserControl } from './UserControl';
import { supabase } from '../lib/supabase';
import type { Subject, Chapter } from '../lib/supabase';

export function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'content' | 'users'>('content');
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Modal states
  const [showSubjectModal, setShowSubjectModal] = useState(false);
  const [showChapterModal, setShowChapterModal] = useState(false);
  const [showContentModal, setShowContentModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<{
    id: string;
    name: string;
    type: 'subject' | 'chapter';
  } | null>(null);
  
  // Form states
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newSubjectIcon, setNewSubjectIcon] = useState('BookOpen');
  const [newChapterName, setNewChapterName] = useState('');
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const [contentForm, setContentForm] = useState({
    readContent: '',
    videoUrl: '',
    extraInfo: '',
    quickRevision: ''
  });

  // Available icons
  const availableIcons = [
    { name: 'Monitor', label: 'Computer', component: Monitor },
    { name: 'Globe2', label: 'Geography', component: Globe2 },
    { name: 'BookOpen', label: 'History', component: BookOpen },
    { name: 'BookText', label: 'Biology', component: BookText },
    { name: 'Flask', label: 'Chemistry', component: Flask },
    { name: 'Atom', label: 'Physics', component: Atom },
    { name: 'Calculator', label: 'Mathematics', component: Calculator },
    { name: 'Languages', label: 'Languages', component: Languages },
    { name: 'BookMarked', label: 'Literature', component: BookMarked },
    { name: 'Book', label: 'English', component: Book }
  ];

  // Icon mapping for lookup
  const iconComponentMap: Record<string, React.ElementType> = {
    'Monitor': Monitor,
    'Globe2': Globe2,
    'BookOpen': BookOpen,
    'BookText': BookText,
    'Flask': Flask,
    'Atom': Atom,
    'Calculator': Calculator,
    'Languages': Languages,
    'BookMarked': BookMarked,
    'Book': Book
  };

  useEffect(() => {
    fetchSubjects();
  }, []);

  useEffect(() => {
    if (selectedSubject) {
      fetchChapters(selectedSubject);
    } else {
      setChapters([]);
    }
  }, [selectedSubject]);

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('subjects')
        .select('*')
        .order('name');
      
      if (error) throw error;
      
      setSubjects(data || []);
      if (data && data.length > 0 && !selectedSubject) {
        setSelectedSubject(data[0].id);
      }
    } catch (err) {
      console.error('Error fetching subjects:', err);
      setError('Failed to load subjects. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const fetchChapters = async (subjectId: string) => {
    try {
      const { data, error } = await supabase
        .from('chapters')
        .select('*')
        .eq('subject_id', subjectId)
        .order('order');
      
      if (error) throw error;
      
      setChapters(data || []);
    } catch (err) {
      console.error('Error fetching chapters:', err);
      setError('Failed to load chapters. Please try again later.');
    }
  };

  const fetchChapterContent = async (chapterId: string) => {
    try {
      const { data, error } = await supabase
        .from('chapter_contents')
        .select('*')
        .eq('chapter_id', chapterId)
        .single();
      
      if (error && error.code !== 'PGRST116') {
        throw error;
      }
      
      if (data) {
        setContentForm({
          readContent: data.read_content || '',
          videoUrl: data.video_url || '',
          extraInfo: data.extra_info || '',
          quickRevision: data.quick_revision || ''
        });
      } else {
        setContentForm({
          readContent: '',
          videoUrl: '',
          extraInfo: '',
          quickRevision: ''
        });
      }
    } catch (err) {
      console.error('Error fetching chapter content:', err);
      setError('Failed to load chapter content. Please try again later.');
    }
  };

  const handleAddSubject = async () => {
    if (!newSubjectName.trim()) return;
    
    try {
      const { data: existingSubjects, error: checkError } = await supabase
        .from('subjects')
        .select('id')
        .eq('name', newSubjectName.trim())
        .limit(1);
      
      if (checkError) throw checkError;
      
      if (existingSubjects && existingSubjects.length > 0) {
        setError(`A subject named "${newSubjectName}" already exists.`);
        return;
      }
      
      const { data, error } = await supabase
        .from('subjects')
        .insert([
          { name: newSubjectName, icon: newSubjectIcon }
        ])
        .select();
      
      if (error) throw error;
      
      await fetchSubjects();
      setNewSubjectName('');
      setNewSubjectIcon('BookOpen');
      setShowSubjectModal(false);
      
      if (data && data.length > 0) {
        setSelectedSubject(data[0].id);
      }
    } catch (err) {
      console.error('Error adding subject:', err);
      setError('Failed to add subject. Please try again later.');
    }
  };

  const handleAddChapter = async () => {
    if (!newChapterName.trim() || !selectedSubject) return;
    
    try {
      const { data: existingChapters, error: orderError } = await supabase
        .from('chapters')
        .select('order')
        .eq('subject_id', selectedSubject)
        .order('order', { ascending: false })
        .limit(1);
      
      if (orderError) throw orderError;
      
      const nextOrder = existingChapters && existingChapters.length > 0 
        ? (existingChapters[0].order + 1) 
        : 1;
      
      const { data, error } = await supabase
        .from('chapters')
        .insert([
          { 
            name: newChapterName, 
            subject_id: selectedSubject,
            order: nextOrder
          }
        ])
        .select();
      
      if (error) throw error;
      
      await fetchChapters(selectedSubject);
      setNewChapterName('');
      setShowChapterModal(false);
      
      if (data && data.length > 0) {
        openContentModal(data[0].id);
      }
    } catch (err) {
      console.error('Error adding chapter:', err);
      setError('Failed to add chapter. Please try again later.');
    }
  };

  const handleSaveContent = async () => {
    if (!selectedChapter) return;
    
    try {
      const { data: existingContent, error: checkError } = await supabase
        .from('chapter_contents')
        .select('id')
        .eq('chapter_id', selectedChapter);
      
      if (checkError) throw checkError;
      
      let result;
      
      if (existingContent && existingContent.length > 0) {
        result = await supabase
          .from('chapter_contents')
          .update({
            read_content: contentForm.readContent,
            video_url: contentForm.videoUrl,
            extra_info: contentForm.extraInfo,
            quick_revision: contentForm.quickRevision,
            updated_at: new Date().toISOString()
          })
          .eq('chapter_id', selectedChapter);
      } else {
        result = await supabase
          .from('chapter_contents')
          .insert([{
            chapter_id: selectedChapter,
            read_content: contentForm.readContent,
            video_url: contentForm.videoUrl,
            extra_info: contentForm.extraInfo,
            quick_revision: contentForm.quickRevision
          }]);
      }
      
      if (result.error) throw result.error;
      
      setShowContentModal(false);
      setSelectedChapter(null);
      
      alert('Chapter content saved successfully!');
    } catch (err) {
      console.error('Error saving chapter content:', err);
      setError('Failed to save chapter content. Please try again later.');
    }
  };

  const handleDeleteSubject = async (subjectId: string) => {
    try {
      const { error } = await supabase
        .from('subjects')
        .delete()
        .eq('id', subjectId);
      
      if (error) throw error;
      
      await fetchSubjects();
      
      if (selectedSubject === subjectId) {
        const remainingSubjects = subjects.filter(subject => subject.id !== subjectId);
        setSelectedSubject(remainingSubjects.length > 0 ? remainingSubjects[0].id : null);
      }
      
      setShowDeleteConfirm(null);
    } catch (err) {
      console.error('Error deleting subject:', err);
      setError('Failed to delete subject. Please try again later.');
    }
  };

  const handleDeleteChapter = async (chapterId: string) => {
    try {
      const { error } = await supabase
        .from('chapters')
        .delete()
        .eq('id', chapterId);
      
      if (error) throw error;
      
      if (selectedSubject) {
        await fetchChapters(selectedSubject);
      }
      setShowDeleteConfirm(null);
    } catch (err) {
      console.error('Error deleting chapter:', err);
      setError('Failed to delete chapter. Please try again later.');
    }
  };

  const handleLogout = async () => {
    try {
      navigate('/admin/login');
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  const openContentModal = (chapterId: string) => {
    setSelectedChapter(chapterId);
    fetchChapterContent(chapterId);
    setShowContentModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-500">
              <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded-md">Ctrl</kbd>
              <span className="mx-1">+</span>
              <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded-md">O</kbd>
              <span className="ml-2">Quick Access</span>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-md flex items-center space-x-2 text-gray-700"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6 flex space-x-4">
          <button
            onClick={() => setActiveTab('content')}
            className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${
              activeTab === 'content'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Layout size={18} />
            <span>Content Management</span>
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${
              activeTab === 'users'
                ? 'bg-blue-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Users size={18} />
            <span>User Control</span>
          </button>
        </div>

        {error && (
          <div className="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
            <span className="block sm:inline">{error}</span>
            <button
              className="absolute top-0 bottom-0 right-0 px-4 py-3"
              onClick={() => setError(null)}
            >
              <span className="sr-only">Dismiss</span>
              <svg className="h-6 w-6 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}

        {activeTab === 'users' ? (
          <UserControl />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Subjects panel */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-800">Subjects</h2>
                <button
                  onClick={() => setShowSubjectModal(true)}
                  className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                >
                  <Plus size={20} />
                </button>
              </div>
              
              {subjects.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <BookOpen size={48} className="mx-auto text-gray-300 mb-4" />
                  <p>No subjects available. Add your first subject!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {subjects.map((subject) => {
                    const Icon = iconComponentMap[subject.icon] || BookOpen;
                    
                    return (
                      <div 
                        key={subject.id}
                        className={`p-3 rounded-lg flex items-center justify-between cursor-pointer ${
                          selectedSubject === subject.id 
                            ? 'bg-blue-50 border border-blue-200' 
                            : 'hover:bg-gray-50 border border-gray-100'
                        }`}
                        onClick={() => setSelectedSubject(subject.id)}
                      >
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <Icon size={20} className="text-blue-600" />
                          </div>
                          <span className="font-medium">{subject.name}</span>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowDeleteConfirm({
                              id: subject.id,
                              name: subject.name,
                              type: 'subject'
                            });
                          }}
                          className="p-1.5 text-gray-400 hover:text-red-500 rounded-full hover:bg-red-50"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Chapters panel */}
            <div className="bg-white rounded-lg shadow-md p-6 lg:col-span-2">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-800">
                  {selectedSubject 
                    ? `Chapters for ${subjects.find(s => s.id === selectedSubject)?.name || ''}` 
                    : 'Chapters'}
                </h2>
                <button
                  onClick={() => setShowChapterModal(true)}
                  disabled={!selectedSubject}
                  className={`p-2 rounded-full ${
                    selectedSubject 
                      ? 'bg-blue-600 text-white hover:bg-blue-700' 
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <Plus size={20} />
                </button>
              </div>
              
              {!selectedSubject ? (
                <div className="text-center py-12 text-gray-500">
                  <Book size={48} className="mx-auto text-gray-300 mb-4" />
                  <p>Select a subject to view its chapters</p>
                </div>
              ) : chapters.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Book size={48} className="mx-auto text-gray-300 mb-4" />
                  <p>No chapters available for this subject. Add your first chapter!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {chapters.map((chapter) => (
                    <div 
                      key={chapter.id}
                      className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
                    >
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium text-gray-800">{chapter.name}</h3>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => openContentModal(chapter.id)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 rounded-full hover:bg-blue-50"
                            title="Edit chapter content"
                          >
                            <Edit size={18} />
                          </button>
                          <button
                            onClick={() => setShowDeleteConfirm({
                              id: chapter.id,
                              name: chapter.name,
                              type: 'chapter'
                            })}
                            className="p-1.5 text-gray-400 hover:text-red-500 rounded-full hover:bg-red-50"
                            title="Delete chapter"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Add Subject Modal */}
      {showSubjectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Add New Subject</h3>
            <div className="space-y-4">
              <div>
                <label htmlFor="subjectName" className="block text-sm font-medium text-gray-700">
                  Subject Name
                </label>
                <input
                  type="text"
                  id="subjectName"
                  value={newSubjectName}
                  onChange={(e) => setNewSubjectName(e.target.value)}
                  placeholder="e.g., Mathematics"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subject Icon
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {availableIcons.map((icon) => {
                    const IconComponent = icon.component;
                    return (
                      <button
                        key={icon.name}
                        type="button"
                        onClick={() => setNewSubjectIcon(icon.name)}
                        className={`p-2 rounded-lg flex flex-col items-center ${
                          newSubjectIcon === icon.name
                            ? 'bg-blue-100 border-2 border-blue-500'
                            : 'border border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        <IconComponent size={24} className="text-blue-600 mb-1" />
                        <span className="text-xs text-gray-600">{icon.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowSubjectModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleAddSubject}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
                >
                  Add Subject
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Chapter Modal */}
      {showChapterModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Add New Chapter</h3>
            <div className="space-y-4">
              <div>
                <label htmlFor="chapterName" className="block text-sm font-medium text-gray-700">
                  Chapter Name
                </label>
                <input
                  type="text"
                  id="chapterName"
                  value={newChapterName}
                  onChange={(e) => setNewChapterName(e.target.value)}
                  placeholder="e.g., Chapter 1: Introduction"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowChapterModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleAddChapter}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
                >
                  Add Chapter
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Chapter Content Modal */}
      {showContentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-semibold mb-4">
              Edit Content for {chapters.find(c => c.id === selectedChapter)?.name || ''}
            </h3>
            
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <FileText size={20} className="text-blue-600 mr-2" />
                  <h4 className="text-md font-medium">Read Chapter Content</h4>
                </div>
                <div>
                  <label htmlFor="readContent" className="block text-sm font-medium text-gray-700 mb-1">
                    PDF URL (Google Drive, Dropbox, etc.)
                  </label>
                  <input
                    type="text"
                    id="readContent"
                    value={contentForm.readContent}
                    onChange={(e) => setContentForm({...contentForm, readContent: e.target.value})}
                    placeholder="https://drive.google.com/file/d/..."
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                  <p className="mt-1 text-xs text-gray-500">
                    For Google Drive: Share the file publicly and use the embed link
                  </p>
                </div>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Video size={20} className="text-blue-600 mr-2" />
                  <h4 className="text-md font-medium">Video Lesson</h4>
                </div>
                <div>
                  <label htmlFor="videoUrl" className="block text-sm font-medium text-gray-700 mb-1">
                    YouTube Video URL
                  </label>
                  <input
                    type="text"
                    id="videoUrl"
                    value={contentForm.videoUrl}
                    onChange={(e) => setContentForm({...contentForm, videoUrl: e.target.value})}
                    placeholder="https://www.youtube.com/watch?v=..."
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Info size={20} className="text-blue-600 mr-2" />
                  <h4 className="text-md font-medium">Extra Information</h4>
                </div>
                <div>
                  <label htmlFor="extraInfo" className="block text-sm font-medium text-gray-700 mb-1">
                    Additional Notes
                  </label>
                  <textarea
                    id="extraInfo"
                    rows={4}
                    value={contentForm.extraInfo}
                    onChange={(e) => setContentForm({...contentForm, extraInfo: e.target.value})}
                    placeholder="Enter additional information about this chapter..."
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Brain size={20} className="text-blue-600 mr-2" />
                  <h4 className="text-md font-medium">Quick Revision</h4>
                </div>
                <div>
                  <label htmlFor="quickRevision" className="block text-sm font-medium text-gray-700 mb-1">
                    Revision Notes
                  </label>
                  <textarea
                    id="quickRevision"
                    rows={4}
                    value={contentForm.quickRevision}
                    onChange={(e) => setContentForm({...contentForm, quickRevision: e.target.value})}
                    placeholder="Enter quick revision notes for this chapter..."
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowContentModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveContent}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
                >
                  Save Content
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

     
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <div className="flex items-center text-red-600 mb-4">
              <AlertCircle size={24} className="mr-2" />
              <h3 className="text-lg font-semibold">Confirm Deletion</h3>
            </div>
            <p className="mb-4">
              Are you sure you want to delete <strong>{showDeleteConfirm.name}</strong>? 
              This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (showDeleteConfirm.type === 'subject') {
                    handleDeleteSubject(showDeleteConfirm.id);
                  } else {
                    handleDeleteChapter(showDeleteConfirm.id);
                  }
                }}
                className="px-4 py-2 bg-red-600 text-white rounded-md text-sm font-medium hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}