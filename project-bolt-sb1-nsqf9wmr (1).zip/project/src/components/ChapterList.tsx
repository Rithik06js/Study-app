import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Book, ArrowLeft, BookOpen } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Chapter, Subject } from '../lib/supabase';

export function ChapterList() {
  const { subjectId } = useParams();
  const navigate = useNavigate();
  const [subject, setSubject] = useState<Subject | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (subjectId) {
      fetchSubjectAndChapters();
    }
  }, [subjectId]);

  // Keyboard shortcut for admin access
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + O shortcut for quick admin access
      if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        navigate('/admin');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [navigate]);

  const fetchSubjectAndChapters = async () => {
    try {
      setLoading(true);
      
      // Fetch subject details
      const { data: subjectData, error: subjectError } = await supabase
        .from('subjects')
        .select('*')
        .eq('id', subjectId)
        .single();
      
      if (subjectError) throw subjectError;
      setSubject(subjectData);
      
      // Fetch chapters for this subject
      const { data: chaptersData, error: chaptersError } = await supabase
        .from('chapters')
        .select('*')
        .eq('subject_id', subjectId)
        .order('order');
      
      if (chaptersError) throw chaptersError;
      setChapters(chaptersData || []);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load chapters. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleBackClick = () => {
    navigate('/subjects');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 p-8 flex flex-col items-center justify-center">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Error</h2>
          <p className="text-gray-700 mb-6">{error}</p>
          <button
            onClick={handleBackClick}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat bg-fixed"
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
        backgroundColor: 'rgba(0,0,0,0.7)',
        backgroundBlendMode: 'overlay',
      }}
    >
      <div className="container mx-auto px-4 py-8">
        <button
          onClick={handleBackClick}
          className="mb-6 flex items-center text-white hover:text-blue-300 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          <span>Back to Subjects</span>
        </button>
        
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-2">{subject?.name}</h1>
            <p className="text-blue-300">Select a chapter to begin studying</p>
            <div className="mt-2 text-white/60 text-sm">
              <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">Ctrl</kbd>
              <span className="mx-1">+</span>
              <kbd className="px-1 py-0.5 bg-white/10 border border-white/20 rounded-md">O</kbd>
              <span className="ml-1">for Admin Access</span>
            </div>
          </div>
          
          <div className="space-y-4">
            {chapters.length === 0 ? (
              <div className="bg-white/10 backdrop-blur-md rounded-xl shadow-lg p-8 text-center border border-white/20">
                <BookOpen size={48} className="mx-auto text-white/50 mb-4" />
                <p className="text-white text-lg">No chapters available for this subject yet.</p>
              </div>
            ) : (
              chapters.map((chapter) => (
                <button
                  key={chapter.id}
                  onClick={() => navigate(`/chapter/${chapter.id}`)}
                  className="w-full p-6 bg-white/10 backdrop-blur-md rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-4 border border-white/20 hover:bg-white/20 hover:scale-[1.02] transform"
                >
                  <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                    <Book size={24} className="text-white" />
                  </div>
                  <div className="text-left">
                    <h2 className="text-xl font-semibold text-white">
                      {chapter.name}
                    </h2>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}