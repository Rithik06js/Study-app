import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { WelcomeScreen } from './components/WelcomeScreen';
import { SubjectsGrid } from './components/SubjectsGrid';
import { ChapterList } from './components/ChapterList';
import { ChapterContent } from './components/ChapterContent';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminLogin } from './components/AdminLogin';
import { ProtectedRoute } from './components/ProtectedRoute';

function App() {
  const [userName, setUserName] = useState('');

  return (
    <BrowserRouter>
      <Routes>
        <Route 
          path="/" 
          element={
            <WelcomeScreen 
              userName={userName} 
              setUserName={setUserName} 
            />
          } 
        />
        <Route 
          path="/subjects" 
          element={
            userName ? 
              <SubjectsGrid userName={userName} /> : 
              <Navigate to="/" replace />
          } 
        />
        <Route 
          path="/subject/:subjectId" 
          element={
            userName ? 
              <ChapterList /> : 
              <Navigate to="/" replace />
          } 
        />
        <Route 
          path="/chapter/:chapterId" 
          element={
            userName ? 
              <ChapterContent /> : 
              <Navigate to="/" replace />
          } 
        />
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route 
          path="/admin/*" 
          element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;