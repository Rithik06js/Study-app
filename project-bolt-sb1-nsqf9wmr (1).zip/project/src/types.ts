export interface Subject {
  id: string;
  name: string;
  icon: string;
  chapters: Chapter[];
}

export interface Chapter {
  id: string;
  subjectId: string;
  name: string;
  content: ChapterContent;
}

export interface ChapterContent {
  id: string;
  chapterId: string;
  readContent: string;
  videoUrl: string;
  extraInfo: string;
  quickRevision: string;
}