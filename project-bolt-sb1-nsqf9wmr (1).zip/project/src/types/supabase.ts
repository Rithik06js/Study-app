export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      subjects: {
        Row: {
          id: string
          name: string
          icon: string
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          icon: string
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          icon?: string
          created_at?: string
        }
        Relationships: []
      }
      chapters: {
        Row: {
          id: string
          subject_id: string
          name: string
          order: number
          created_at: string
        }
        Insert: {
          id?: string
          subject_id: string
          name: string
          order?: number
          created_at?: string
        }
        Update: {
          id?: string
          subject_id?: string
          name?: string
          order?: number
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "chapters_subject_id_fkey"
            columns: ["subject_id"]
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          }
        ]
      }
      chapter_contents: {
        Row: {
          id: string
          chapter_id: string
          read_content: string | null
          video_url: string | null
          extra_info: string | null
          quick_revision: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          chapter_id: string
          read_content?: string | null
          video_url?: string | null
          extra_info?: string | null
          quick_revision?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          chapter_id?: string
          read_content?: string | null
          video_url?: string | null
          extra_info?: string | null
          quick_revision?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "chapter_contents_chapter_id_fkey"
            columns: ["chapter_id"]
            referencedRelation: "chapters"
            referencedColumns: ["id"]
          }
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}